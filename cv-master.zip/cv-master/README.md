# Readme
Thank you _Mr. Akdogan_ for acceptig our _ToS_/_EULA_.<br>
You're _only_ allowed to change the code, If you ask the licensee for permission.
